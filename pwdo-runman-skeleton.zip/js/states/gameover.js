define('GameOver',[

], function(){
	var GameOver;
	

	return GameOver;
});